from typing import Optional

def fetch_rates(province: Optional[str] = None):
    sample = [{"lender":"Sample Lender","termMonths":60,"rateAPR":5.29,"province":province}]
    return sample
