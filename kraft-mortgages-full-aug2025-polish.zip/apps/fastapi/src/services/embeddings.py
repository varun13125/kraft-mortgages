# Placeholder for embeddings/vector operations
def embed_text(text: str) -> list[float]:
    return [0.0]
