import Link from "next/link";
export function CalculatorCard({ title, href }: { title: string; href: string }) {
  return (
    <Link href={href} className="block rounded-2xl p-6 shadow hover:shadow-lg transition">
      <div className="text-xl font-semibold">{title}</div>
      <div className="text-sm text-muted-foreground">Open tool →</div>
    </Link>
  );
}
