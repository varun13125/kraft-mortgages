"use client";
import { useAppStore } from "@/store/useAppStore";

export function ProvinceSelect() {
  const { province, setProvince } = useAppStore();
  return (
    <select className="border rounded px-2 py-1 text-sm" value={province} onChange={e=>setProvince(e.target.value as any)} aria-label="Province">
      <option value="BC">BC</option>
      <option value="AB">AB</option>
      <option value="ON">ON</option>
    </select>
  );
}
