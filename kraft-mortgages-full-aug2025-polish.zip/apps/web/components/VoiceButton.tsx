"use client";
export function VoiceButton() {
  return (
    <button className="rounded px-3 py-2 border" title="Voice (coming soon)">
      🎙️ Ask Victoria
    </button>
  );
}
