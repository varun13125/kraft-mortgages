import Link from "next/link";
import { ProvinceSelect } from "@/components/ProvinceSelect";

export function Nav() {
  return (
    <nav className="flex gap-4 text-sm">
      <Link href="/calculators/payment">Payment</Link>
      <Link href="/calculators/affordability">Affordability</Link>
      <Link href="/calculators/renewal">Renewal</Link>
      <Link href="/mli-select">MLI Select</Link>
      <Link href="/provinces/bc">BC</Link>
      <Link href="/provinces/ab">AB</Link>
      <Link href="/provinces/on">ON</Link>
    <a href="/admin" className="ml-4">Admin</a>
    <a href="/admin/rates" className="ml-2">Rates</a>
    <a href="/admin/analytics" className="ml-2">Analytics</a>
    <Link href="/settings">Settings</Link>
      <ProvinceSelect />
    </nav>
  );
}
