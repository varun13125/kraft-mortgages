"use client";
import { useState } from "react";
import { useAppStore } from "@/store/useAppStore";
import { ComplianceBanner } from "@/components/ComplianceBanner";

export function ChatAlex() {
  const { province, language } = useAppStore();
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<string[]>([]);

  async function send() {
    const res = await fetch("/api/chat", { method: "POST", body: JSON.stringify({ input, province, language }), headers: {"content-type":"application/json"} });
    const reader = res.body!.getReader();
    const decoder = new TextDecoder();
    let acc = "";
    for(;;){
      const { value, done } = await reader.read();
      if (done) break;
      acc += decoder.decode(value);
      setMessages(prev => [...prev.slice(0, -1), acc]);
    }
  }

  return (
    <div className="rounded-2xl border p-4 space-y-3">\n      <ComplianceBanner feature="CHATBOT" />
      <div className="font-semibold">Alex — Senior Mortgage Advisor</div>
      <div className="min-h-[120px] bg-gray-50 rounded p-3 text-sm">
        {messages.length === 0 ? <div className="text-muted-foreground">Ask about rates, qualification, or programs in BC/AB/ON.</div> : messages.map((m,i)=> <p key={i}>{m}</p>)}
      </div>
      <div className="flex gap-2">
        <input className="flex-1 border rounded p-2" value={input} onChange={e=>setInput(e.target.value)} placeholder="e.g., First home in Calgary..." />
        <button className="rounded px-4 py-2 bg-black text-white" onClick={send}>Send</button>
      </div>
    </div>
  );
}
