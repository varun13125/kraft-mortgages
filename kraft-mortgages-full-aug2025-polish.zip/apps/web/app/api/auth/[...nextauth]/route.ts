import NextAuth from "next-auth";
import Credentials from "next-auth/providers/credentials";

const handler = NextAuth({
  providers: [
    Credentials({
      name: "Dev Credentials",
      credentials: { email: { label: "Email", type: "text" } },
      async authorize(credentials) {
        if (!credentials?.email) return null;
        return { id: credentials.email, name: credentials.email, email: credentials.email } as any;
      }
    })
  ],
  session: { strategy: "jwt" }
});
export { handler as GET, handler as POST };
