import Link from "next/link";
import { ChatAlex } from "@/components/ChatAlex";
import { CalculatorCard } from "@/components/CalculatorCard";

export default function Home() {
  return (
    <main className="min-h-screen px-6 py-10 space-y-12">
      <section className="text-center space-y-4">
        <h1 className="text-4xl font-bold">Kraft Mortgages Canada</h1>
        <p className="text-muted-foreground">
          AI‑powered brokerage for BC • Alberta • Ontario.
        </p>
      </section>

      <section className="grid gap-6 md:grid-cols-3">
        <CalculatorCard title="Mortgage Payment" href="/calculators/payment" />
        <CalculatorCard title="Affordability" href="/calculators/affordability" />
        <CalculatorCard title="Renewal Optimizer" href="/calculators/renewal" />
      
      <script type="application/ld+json" suppressHydrationWarning dangerouslySetInnerHTML={{ __html: JSON.stringify({
        "@context":"https://schema.org",
        "@type":"Organization",
        "name":"Kraft Mortgages Canada Inc.",
        "url":process.env.NEXTAUTH_URL || "http://localhost:3000",
        "logo":"/icons/icon-192.png",
        "areaServed":["CA-BC","CA-AB","CA-ON"]
      }) }} />
    

      <section>
        <ChatAlex />
      </section>

      <section className="grid gap-6 md:grid-cols-3">
        <Link className="underline" href="/provinces/bc">British Columbia</Link>
        <Link className="underline" href="/provinces/ab">Alberta</Link>
        <Link className="underline" href="/provinces/on">Ontario</Link>
      </section>
    </main>
  );
}
