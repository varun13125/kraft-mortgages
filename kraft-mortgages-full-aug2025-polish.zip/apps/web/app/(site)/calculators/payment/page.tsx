"use client";
import { useState } from "react";
import { payment, biweeklySavings } from "@/lib/calc/payment";\nimport { ComplianceBanner } from "@/components/ComplianceBanner";

export default function PaymentCalculatorPage() {
  const [principal, setPrincipal] = useState(700000);
  const [rate, setRate] = useState(5.34);
  const [years, setYears] = useState(25);

  const monthly = payment({ principal, annualRatePct: rate, amortYears: years, paymentsPerYear: 12 });
  const { acceleratedBiweekly, annualSavings } = biweeklySavings({ principal, annualRatePct: rate, amortYears: years });

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <h2 className="text-2xl font-semibold">Smart Mortgage Payment Calculator</h2>\n      <div className="mt-2"><ComplianceBanner feature="LEAD_FORM" /></div>
      <div className="grid gap-4">
        <label className="grid gap-1">Principal
          <input type="number" value={principal} onChange={e=>setPrincipal(+e.target.value)} className="border rounded p-2" />
        </label>
        <label className="grid gap-1">Rate (APR %)
          <input type="number" step="0.01" value={rate} onChange={e=>setRate(+e.target.value)} className="border rounded p-2" />
        </label>
        <label className="grid gap-1">Amortization (years)
          <input type="number" value={years} onChange={e=>setYears(+e.target.value)} className="border rounded p-2" />
        </label>
      </div>

      <div className="rounded-2xl p-4 bg-gray-50">
        <div>Monthly: <strong>${monthly.toFixed(2)}</strong></div>
        <div>Accelerated Bi‑weekly: <strong>${acceleratedBiweekly.toFixed(2)}</strong></div>
        <div>Projected Annual Savings: <strong>${annualSavings.toFixed(2)}</strong></div>
      </div>

      <p className="text-sm text-muted-foreground">Includes payment frequency comparison. Provincial taxes/fees can be layered from live data later.</p>
    </div>
  );
}
