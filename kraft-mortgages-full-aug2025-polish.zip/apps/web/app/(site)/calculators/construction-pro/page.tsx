"use client";
import { useMemo, useState } from "react";
import { interestOnlyCost } from "@/lib/calc/construction";

import { ComplianceBanner } from "@/components/ComplianceBanner";

export default function ConstructionPro() {
  const [rate, setRate] = useState(7.25);
  const [draws, setDraws] = useState([{ month:1, amount:200000 }, { month:4, amount:250000 }, { month:7, amount:300000 }] as {month:number,amount:number}[]);
  const result = useMemo(()=>interestOnlyCost({ draws, annualRatePct: rate }), [draws, rate]);

  return (
    <div className="max-w-3xl space-y-6">
      \1\n      <div className="mt-2"><ComplianceBanner feature="CALC_CONSTRUCTION" /></div>
      <div className="grid gap-3 md:grid-cols-2">
        <label className="grid gap-1">Construction Rate (APR %)
          <input type="number" step="0.01" value={rate} onChange={e=>setRate(+e.target.value)} className="border rounded p-2" />
        </label>
      </div>

      <div className="space-y-2">
        <div className="text-sm font-medium">Draw Schedule</div>
        {draws.map((d,i)=> (
          <div key={i} className="grid grid-cols-2 gap-2">
            <input className="border rounded p-2" type="number" value={d.month} onChange={e=>setDraws(prev=>prev.map((x,j)=> j===i?{...x, month:+e.target.value}:x))} />
            <input className="border rounded p-2" type="number" value={d.amount} onChange={e=>setDraws(prev=>prev.map((x,j)=> j===i?{...x, amount:+e.target.value}:x))} />
          </div>
        ))}
        <button className="text-sm underline" onClick={()=>setDraws(d=>[...d,{month:(d.at(-1)?.month||1)+1, amount:100000}])}>+ Add draw</button>
      </div>

      <div className="rounded-2xl bg-gray-50 p-4 space-y-2">
        <div>Total Interest (construction period): <strong>${result.totalInterest.toFixed(2)}</strong></div>
        <div className="text-xs text-muted-foreground">Assumes interest‑only during build; finalize with lender draw timing & compounding.</div>
      </div>
    </div>
  );
}
