"use client";
import { useState } from "react";
import { cashflow } from "@/lib/calc/investment";

import { ComplianceBanner } from "@/components/ComplianceBanner";

export default function Investment() {
  const [price, setPrice] = useState(800000);
  const [down, setDown] = useState(200000);
  const [rate, setRate] = useState(5.45);
  const [years, setYears] = useState(25);
  const [rent, setRent] = useState(4200);
  const [vacancy, setVacancy] = useState(3);
  const [expenses, setExpenses] = useState(1200);
  const r = cashflow({ price, downPayment: down, ratePct: rate, amortYears: years, rentMonthly: rent, vacancyPct: vacancy, expensesMonthly: expenses });

  return (
    <div className="max-w-2xl space-y-6">
      \1\n      <div className="mt-2"><ComplianceBanner feature="LEAD_FORM" /></div>
      <div className="grid gap-3 md:grid-cols-2">
        <label className="grid gap-1">Purchase Price <input className="border rounded p-2" type="number" value={price} onChange={e=>setPrice(+e.target.value)} /></label>
        <label className="grid gap-1">Down Payment <input className="border rounded p-2" type="number" value={down} onChange={e=>setDown(+e.target.value)} /></label>
        <label className="grid gap-1">Rate (APR %) <input className="border rounded p-2" type="number" step="0.01" value={rate} onChange={e=>setRate(+e.target.value)} /></label>
        <label className="grid gap-1">Amortization (yrs) <input className="border rounded p-2" type="number" value={years} onChange={e=>setYears(+e.target.value)} /></label>
        <label className="grid gap-1">Gross Rent (mo) <input className="border rounded p-2" type="number" value={rent} onChange={e=>setRent(+e.target.value)} /></label>
        <label className="grid gap-1">Vacancy (%) <input className="border rounded p-2" type="number" value={vacancy} onChange={e=>setVacancy(+e.target.value)} /></label>
        <label className="grid gap-1">Expenses (mo) <input className="border rounded p-2" type="number" value={expenses} onChange={e=>setExpenses(+e.target.value)} /></label>
      </div>
      <div className="rounded-2xl bg-gray-50 p-4 space-y-1">
        <div>Monthly Payment: <strong>${r.pmt.toFixed(2)}</strong></div>
        <div>NOI (mo): <strong>${r.noi.toFixed(2)}</strong></div>
        <div>Cash Flow (mo): <strong className={r.cf>=0?"text-green-700":"text-red-700"}>${r.cf.toFixed(2)}</strong></div>
        <div>Cap Rate: <strong>{r.capRate.toFixed(2)}%</strong></div>
        <div>DSCR: <strong>{r.dscr.toFixed(2)}</strong></div>
      </div>
    </div>
  );
}
