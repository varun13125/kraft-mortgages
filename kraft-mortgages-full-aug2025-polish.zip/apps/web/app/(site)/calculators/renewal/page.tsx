"use client";
import { useState } from "react";
import { payment } from "@/lib/calc/payment";

import { ComplianceBanner } from "@/components/ComplianceBanner";

export default function Renewal() {
  const [balance, setBalance] = useState(450000);
  const [monthsLeft, setMonthsLeft] = useState(36);
  const [currentRate, setCurrentRate] = useState(5.89);
  const [marketRate, setMarketRate] = useState(5.19);
  const [penalty, setPenalty] = useState(2500);

  const currPay = payment({ principal: balance, annualRatePct: currentRate, amortYears: Math.ceil(monthsLeft/12), paymentsPerYear: 12 });
  const newPay = payment({ principal: balance, annualRatePct: marketRate, amortYears: Math.ceil(monthsLeft/12), paymentsPerYear: 12 });
  const monthlySavings = currPay - newPay;
  const breakEvenMonths = monthlySavings > 0 ? Math.ceil(penalty / monthlySavings) : 0;

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      \1\n      <div className="mt-2"><ComplianceBanner feature="LEAD_FORM" /></div>
      <div className="grid gap-3 md:grid-cols-2">
        <label className="grid gap-1">Remaining Balance
          <input type="number" value={balance} onChange={e=>setBalance(+e.target.value)} className="border rounded p-2" />
        </label>
        <label className="grid gap-1">Months Remaining
          <input type="number" value={monthsLeft} onChange={e=>setMonthsLeft(+e.target.value)} className="border rounded p-2" />
        </label>
        <label className="grid gap-1">Current Rate (APR %)
          <input type="number" step="0.01" value={currentRate} onChange={e=>setCurrentRate(+e.target.value)} className="border rounded p-2" />
        </label>
        <label className="grid gap-1">Market Rate (APR %)
          <input type="number" step="0.01" value={marketRate} onChange={e=>setMarketRate(+e.target.value)} className="border rounded p-2" />
        </label>
        <label className="grid gap-1">Estimated Penalty ($)
          <input type="number" value={penalty} onChange={e=>setPenalty(+e.target.value)} className="border rounded p-2" />
        </label>
      </div>

      <div className="rounded-2xl p-4 bg-gray-50 space-y-2">
        <div>Current Monthly: <strong>${currPay.toFixed(2)}</strong></div>
        <div>New Monthly (if switch): <strong>${newPay.toFixed(2)}</strong></div>
        <div>Monthly Savings: <strong>${monthlySavings.toFixed(2)}</strong></div>
        <div>Break‑even: <strong>{breakEvenMonths} months</strong></div>
        <p className="text-xs text-muted-foreground">Penalties vary by lender and term; confirm with your lender. Educational use only.</p>
      </div>
    </div>
  );
}
