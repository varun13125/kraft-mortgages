export default function ON() {
  return (
    <div className="space-y-3">
      <h2 className="text-2xl font-semibold">Ontario (FSRAO)</h2>
      <p className="text-sm text-muted-foreground">Enhanced private mortgage regulations active. Page will surface Ontario programs and guidance.</p>
    </div>
  );
}
