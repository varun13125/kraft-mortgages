"use client";
import { useMemo, useState } from "react";
import { estimateMliPremium } from "@/lib/calc/mli";

import { ComplianceBanner } from "@/components/ComplianceBanner";

export default function MLISelect() {
  const [units, setUnits] = useState(24);
  const [price, setPrice] = useState(6500000);
  const [loan, setLoan] = useState(5200000);
  const [scores, setScores] = useState({ affordability: 65, energy: 58, accessibility: 62 });

  const result = useMemo(() => estimateMliPremium({ units, purchasePrice: price, loanAmount: loan, termYears: 10, scores }), [units, price, loan, scores]);

  return (
    <div className="max-w-3xl space-y-6">
      \1\n      <div className="mt-2"><ComplianceBanner feature="CALC_MLI" /></div>
      <div className="grid gap-3 md:grid-cols-3">
        <label className="grid gap-1">Units
          <input type="number" value={units} onChange={e=>setUnits(+e.target.value)} className="border rounded p-2" />
        </label>
        <label className="grid gap-1">Purchase Price
          <input type="number" value={price} onChange={e=>setPrice(+e.target.value)} className="border rounded p-2" />
        </label>
        <label className="grid gap-1">Loan Amount
          <input type="number" value={loan} onChange={e=>setLoan(+e.target.value)} className="border rounded p-2" />
        </label>
      </div>

      <div className="grid gap-3 md:grid-cols-3">
        {(["affordability","energy","accessibility"] as const).map((k)=> (
          <label key={k} className="grid gap-1 capitalize">{k} score
            <input type="number" min={0} max={100} value={(scores as any)[k]}
              onChange={e=>setScores(s=>({ ...s, [k]: +e.target.value }))}
              className="border rounded p-2" />
          </label>
        ))}
      </div>

      <div className="rounded-2xl bg-gray-50 p-4 space-y-2">
        <div>Premium Rate (est.): <strong>{(result.rate*100).toFixed(2)}%</strong></div>
        <div>Premium Amount: <strong>${result.premium.toLocaleString()}</strong></div>
        <div>Pillars Attained: <strong>{result.attained.length ? result.attained.join(", ") : "None"}</strong></div>
        <p className="text-xs text-muted-foreground">Figures are estimates. Confirm with official CMHC tables before advising clients.</p>
      </div>
    </div>
  );
}
