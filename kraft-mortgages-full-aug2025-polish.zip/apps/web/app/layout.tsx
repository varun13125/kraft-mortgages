import "./globals.css";
import Link from "next/link";
import { Analytics } from "@/components/Analytics";
import { Nav } from "@/components/Nav";
import { PrefSync } from "@/components/PrefSync";
import { PWA } from "@/components/PWA";

export const metadata = {
  title: "Kraft Mortgages Canada",
  description: "AI‑powered mortgage brokerage for BC, Alberta, and Ontario"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <header className="border-b">
          <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
            <Link href="/" className="font-semibold">Kraft Mortgages</Link>
            <Nav />
          </div>
        </header>
        <div className="max-w-6xl mx-auto px-4 py-8"><PrefSync />{children}</div>
        <footer className="border-t mt-16">
          <div className="max-w-6xl mx-auto px-4 py-8 text-sm text-muted-foreground">
            © {new Date().getFullYear()} Kraft Mortgages Canada — BC • AB • ON
          </div>
        </footer>
        <Analytics />
      </body>
    </html>
  );
}
